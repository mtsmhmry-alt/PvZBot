بناء التطبيق من الجوال بدون كمبيوتر:
1) سوّ حساب على github.com وأنشئ مستودع جديد (New repository).
2) أنشئ الملفات واحد واحد: Add file > Create new file، اكتب المسار كامل في خانة الاسم
   (مثال: app/src/main/java/com/example/autoclicker/ClickService.kt) والصق المحتوى.
   الملفات: settings.gradle.kts, build.gradle.kts, gradle.properties, app/build.gradle.kts,
   app/src/main/AndroidManifest.xml, app/src/main/res/xml/accessibility_config.xml,
   app/src/main/res/values/strings.xml, app/src/main/java/com/example/autoclicker/MainActivity.kt,
   app/src/main/java/com/example/autoclicker/ClickService.kt, .github/workflows/build.yml
3) تبويب Actions > Build APK > ستشتغل تلقائياً بعد كل ملف. بعد النجاح افتحها ونزّل app-debug من Artifacts.
4) ثبّت الـAPK (اسمح بالتثبيت من المتصفح) وفعّل خدمة PvZ Bot من إمكانية الوصول.
