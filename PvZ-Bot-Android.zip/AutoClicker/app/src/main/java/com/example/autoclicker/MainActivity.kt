package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "PvZ Bot\n\n" +
                "1) فعّل خدمة PvZ Bot من إعدادات إمكانية الوصول\n" +
                "2) افتح اللعبة وادخل مرحلة\n" +
                "3) اضغط ⚙ وحرّك الدوائر: TL فوق أول مربع (يسار فوق)، BR فوق آخر مربع (يمين تحت)، S فوق بطاقة دوار الشمس، P فوق بطاقة الرامي\n" +
                "4) اسحب اللوحة (≡) لمكان خارج الملعب، ثم اضغط ⚙ للقفل\n" +
                "5) اضغط ▶ والملعب فاضي قبل ما تنزل أي نبات أو يجي زومبي"
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(root)
    }
}
