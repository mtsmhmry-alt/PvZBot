package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * بوت PvZ بسيط:
 * - يلتقط الشاشة، يقارنها بصورة الملعب الفاضي، ويكتشف الزومبي (تغيّر في الأعمدة اليمنى)
 * - يزرع دوار شمس في العمود الأول، ورماة في الصفوف اللي فيها زومبي
 * - يجمع الشمس
 * افتراض: الملعب 5 صفوف × 9 أعمدة، والزرع = اضغط البطاقة ثم المربع.
 */
class ClickService : AccessibilityService() {

    companion object {
        const val ROWS = 5
        const val COLS = 9
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private class Marker(val view: TextView, val lp: WindowManager.LayoutParams)
    private class Plant(val type: Char, var confirmed: Boolean = false, var misses: Int = 0, var age: Int = 0)

    private val markers = mutableListOf<Marker>() // TL, BR, S, P
    private lateinit var panelLp: WindowManager.LayoutParams
    private var panel: View? = null
    private lateinit var playBtn: Button

    private var calibrating = true
    private var running = false

    // هندسة الملعب
    private var x0 = 0f
    private var y0 = 0f
    private var cw = 0f
    private var ch = 0f
    private var cardS = PointF()
    private var cardP = PointF()

    private var baseline: Array<Array<IntArray>>? = null
    private val plants = HashMap<Int, Plant>()
    private var sunRotate = 0

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addMarker("TL", Color.rgb(220, 50, 50), 600, 350)
        addMarker("BR", Color.rgb(50, 90, 220), 1900, 950)
        addMarker("S", Color.rgb(230, 170, 0), 300, 100)
        addMarker("P", Color.rgb(40, 160, 70), 450, 100)
        addPanel()
        toast("اضبط الدوائر ثم اضغط ⚙ للقفل")
    }

    // ---------- واجهة ----------

    private fun overlayParams(w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun addMarker(label: String, color: Int, x: Int, y: Int) {
        val tv = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(170, Color.red(color), Color.green(color), Color.blue(color)))
                setStroke(4, Color.WHITE)
            }
        }
        val lp = overlayParams(100, 100, true).apply { this.x = x; this.y = y }
        makeDraggable(tv, lp, tv)
        wm.addView(tv, lp)
        markers.add(Marker(tv, lp))
    }

    private fun addPanel() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(210, 30, 30, 30))
            setPadding(8, 8, 8, 8)
            gravity = Gravity.CENTER_VERTICAL
        }
        val handle = TextView(this).apply {
            text = "≡"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(24, 0, 24, 0)
        }
        val calBtn = Button(this).apply { text = "⚙"; setOnClickListener { onCalibClick() } }
        playBtn = Button(this).apply { text = "▶"; setOnClickListener { togglePlay() } }
        layout.addView(handle); layout.addView(calBtn); layout.addView(playBtn)

        panelLp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
            .apply { x = 20; y = 20 }
        makeDraggable(handle, panelLp, layout)
        wm.addView(layout, panelLp)
        panel = layout
    }

    private fun makeDraggable(touchView: View, lp: WindowManager.LayoutParams, windowView: View) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        touchView.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(windowView, lp)
                }
            }
            true
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- المعايرة ----------

    private fun center(m: Marker): PointF {
        val l = IntArray(2)
        m.view.getLocationOnScreen(l)
        return PointF(l[0] + m.view.width / 2f, l[1] + m.view.height / 2f)
    }

    private fun onCalibClick() {
        if (running) stopBot()
        setCalibrating(!calibrating)
    }

    /** يرجع true إذا تغيّرت الحالة فعلاً */
    private fun setCalibrating(on: Boolean): Boolean {
        if (!on) {
            val tl = center(markers[0]); val br = center(markers[1])
            val w = (br.x - tl.x) / (COLS - 1)
            val h = (br.y - tl.y) / (ROWS - 1)
            if (w < 20f || h < 20f) {
                toast("TL لازم يكون فوق يسار، و BR تحت يمين")
                return false
            }
            x0 = tl.x; y0 = tl.y; cw = w; ch = h
            cardS = center(markers[2]); cardP = center(markers[3])
        }
        calibrating = on
        for (m in markers) {
            m.view.visibility = if (on) View.VISIBLE else View.INVISIBLE
            m.lp.flags = if (on) m.lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else m.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(m.view, m.lp)
        }
        baseline = null
        plants.clear()
        toast(if (on) "وضع المعايرة" else "تم القفل")
        return true
    }

    // ---------- تشغيل / إيقاف ----------

    private fun togglePlay() {
        if (running) { stopBot(); return }
        if (calibrating && !setCalibrating(false)) return
        baseline = null
        plants.clear()
        running = true
        playBtn.text = "⏸"
        toast("يلتقط صورة الملعب الفاضي… لا تلمس الشاشة")
        next(800)
    }

    private fun stopBot() {
        running = false
        handler.removeCallbacksAndMessages(null)
        playBtn.text = "▶"
    }

    private fun next(delayMs: Long) {
        if (!running) return
        handler.postDelayed({ cycle() }, delayMs)
    }

    // ---------- الحلقة الرئيسية ----------

    private fun cycle() {
        if (!running) return
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hw = result.hardwareBuffer
                val hwBmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                val bmp = hwBmp?.copy(Bitmap.Config.ARGB_8888, false)
                hwBmp?.recycle()
                hw.close()
                if (bmp != null && running) process(bmp) else next(1500)
            }

            override fun onFailure(errorCode: Int) {
                next(1500)
            }
        })
    }

    private fun cellCenter(r: Int, c: Int) = PointF(x0 + c * cw, y0 + r * ch)

    private fun sample(bmp: Bitmap): Array<Array<IntArray>> =
        Array(ROWS) { r ->
            Array(COLS) { c ->
                val cx = x0 + c * cw
                val cy = y0 + r * ch
                IntArray(25) { k ->
                    val i = k / 5 - 2
                    val j = k % 5 - 2
                    val px = (cx + i * cw * 0.18f).toInt().coerceIn(0, bmp.width - 1)
                    val py = (cy + j * ch * 0.18f).toInt().coerceIn(0, bmp.height - 1)
                    bmp.getPixel(px, py)
                }
            }
        }

    private fun isSun(c: Int) = Color.red(c) > 230 && Color.green(c) > 190 && Color.blue(c) < 110

    private fun frac(cur: Array<Array<IntArray>>, base: Array<Array<IntArray>>, r: Int, c: Int, skipSun: Boolean): Float {
        val a = cur[r][c]; val b = base[r][c]
        var n = 0
        for (k in a.indices) {
            if (skipSun && isSun(a[k])) continue
            val d = abs(Color.red(a[k]) - Color.red(b[k])) +
                abs(Color.green(a[k]) - Color.green(b[k])) +
                abs(Color.blue(a[k]) - Color.blue(b[k]))
            if (d > 90) n++
        }
        return n / a.size.toFloat()
    }

    private fun process(bmp: Bitmap) {
        val cur = sample(bmp)
        bmp.recycle()
        val base = baseline
        if (base == null) {
            baseline = cur
            toast("تمام، البوت شغّال")
            next(1200)
            return
        }

        val occupied = Array(ROWS) { r -> BooleanArray(COLS) { c -> frac(cur, base, r, c, false) > 0.2f } }
        val zombieRow = BooleanArray(ROWS) { r ->
            (COLS - 4 until COLS).any { c -> frac(cur, base, r, c, true) > 0.06f }
        }

        // تحديث حالة النباتات (تأكيد الزرع / اكتشاف المأكول)
        val iter = plants.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            val occ = occupied[e.key / COLS][e.key % COLS]
            val p = e.value
            if (p.confirmed) {
                if (occ) p.misses = 0 else if (++p.misses >= 2) iter.remove()
            } else {
                if (occ) p.confirmed = true else if (++p.age >= 3) iter.remove()
            }
        }

        val taps = mutableListOf<PointF>()

        // شمس في مربعات فاضية
        var sunTaps = 0
        loop@ for (r in 0 until ROWS) for (c in 0 until COLS) {
            if (occupied[r][c] || plants.containsKey(r * COLS + c)) continue
            if (cur[r][c].count { isSun(it) } >= 5) {
                taps.add(cellCenter(r, c))
                if (++sunTaps >= 3) break@loop
            }
        }

        // شمس تطلع من دوار الشمس: اضغط عليها بالتناوب
        val sunflowers = plants.entries.filter { it.value.type == 'S' && it.value.confirmed }.map { it.key }.sorted()
        if (sunflowers.isNotEmpty()) {
            repeat(minOf(2, sunflowers.size)) {
                val k = sunflowers[sunRotate % sunflowers.size]
                sunRotate++
                taps.add(cellCenter(k / COLS, k % COLS))
            }
        }

        // قرار الزرع (نبتة وحدة في كل دورة)
        decidePlant(occupied, zombieRow)?.let { (type, r, c) ->
            taps.add(if (type == 'S') cardS else cardP)
            taps.add(cellCenter(r, c))
            plants[r * COLS + c] = Plant(type)
        }

        runTaps(taps)
        next(taps.size * 320L + 1100L)
    }

    private fun decidePlant(occupied: Array<BooleanArray>, zombieRow: BooleanArray): Triple<Char, Int, Int>? {
        fun free(r: Int, c: Int) = !occupied[r][c] && !plants.containsKey(r * COLS + c)
        fun count(type: Char, row: Int = -1) =
            plants.entries.count { it.value.type == type && (row < 0 || it.key / COLS == row) }
        val rowsOrder = listOf(2, 1, 3, 0, 4)

        if (count('S') < 2) rowsOrder.firstOrNull { free(it, 0) }?.let { return Triple('S', it, 0) }
        for (r in rowsOrder) if (zombieRow[r] && count('P', r) < 2)
            (1..3).firstOrNull { free(r, it) }?.let { return Triple('P', r, it) }
        if (count('S') < 5) rowsOrder.firstOrNull { free(it, 0) }?.let { return Triple('S', it, 0) }
        for (r in rowsOrder) if (count('P', r) < 1)
            (1..3).firstOrNull { free(r, it) }?.let { return Triple('P', r, it) }
        return null
    }

    // ---------- النقر ----------

    private fun runTaps(points: List<PointF>) {
        points.forEachIndexed { i, p ->
            handler.postDelayed({ if (running) tap(p.x, p.y) }, i * 320L)
        }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 30)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopBot() }

    override fun onDestroy() {
        stopBot()
        markers.forEach { wm.removeView(it.view) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
